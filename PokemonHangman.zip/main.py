from replit import clear
#Step 5

import random
from hangman_art import logo, stages, poke_logo
from pokemon_0all import pokemon_names_all
from pokemon_1kanto import pokemon_names_kanto
from pokemon_2johto import pokemon_names_johto
from pokemon_3hoenn import pokemon_names_hoenn
from pokemon_4sinnoh import pokemon_names_sinnoh
from pokemon_5unova import pokemon_names_unova
from pokemon_6kalos import pokemon_names_kalos
from pokemon_7alola import pokemon_names_alola
from pokemon_8galar import pokemon_names_galar

region_choice = int(input("""
Which region of Pokemon would you like to use? 
Please type: 
1 for Kanto, 
2 for Johto, 
3 for Hoenn, 
4 for Sinnoh, 
5 for Unova, 
6 for Kalos, 
7 for Alola, 
8 for Galar, 
or 0 for All.
"""))

region_list = [pokemon_names_all, pokemon_names_kanto, pokemon_names_johto, pokemon_names_hoenn, pokemon_names_sinnoh, pokemon_names_unova, pokemon_names_kalos, pokemon_names_alola, pokemon_names_galar]

clear()

chosen_word = random.choice(region_list[region_choice])
word_length = len(chosen_word)

end_of_game = False
lives = 6

#Start of Game

print(poke_logo)
print(logo)

#Testing code
# print(f'Pssst, the solution is {chosen_word}.')

display = []
guesses = []
for _ in range(word_length):
    display += "_"

while not end_of_game:
    guess = input("Guess a letter: ").lower()
    clear() 

    #Guess Same Letter Again
    if guess in guesses:
        print(f"You already selected {guess}. Try again.")
        print(f"\n{' '.join(display)}")
        print(f"Previous guesses: {' '.join(guesses)}")
        continue
    
    #Check guessed letter
    for position in range(word_length):
        letter = chosen_word[position]
        # print(f"Current position: {position}\n Current letter: {letter}\n Guessed letter: {guess}")
        if letter == guess:
            print(" ")
            display[position] = letter

    #Check if user is wrong.
    if guess not in chosen_word:
        #TODO-5: - If the letter is not in the chosen_word, print out the letter and let them know it's not in the word.
        lives -= 1
        print(f"You guessed {guess}, that's not in the word.  You lose a life.")
        if lives == 0:
            end_of_game = True
            print(f"\nThe word was {chosen_word}. You lose.")
            break
    guesses += guess
    
    #Join all the elements in the list and turn it into a String.
    print(f"\n{' '.join(display)}")
    print(f"Previous guesses: {' '.join(guesses)}")
    print(f"Lives Remaining: {lives}")

    # Check if user has got all letters.
    if "_" not in display:
        end_of_game = True
        print("\nCongratulations! You win!")
        break

    #Print Current Hangman Image
    print(stages[lives])